-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2016 at 04:27 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mamams`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`) VALUES
(1, 'iksanul', 'iksan123'),
(2, 'ghazwan', 'ghaz123'),
(3, 'iqbal', 'iqbal123');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id_menu` int(11) NOT NULL,
  `id_toko` int(11) DEFAULT NULL,
  `nm_menu` varchar(50) DEFAULT NULL,
  `kategori` varchar(30) DEFAULT NULL,
  `jenis` varchar(20) DEFAULT NULL,
  `harga` int(11) DEFAULT NULL,
  `ulasan` text,
  `nm_foto` varchar(40) DEFAULT NULL,
  `waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id_menu`, `id_toko`, `nm_menu`, `kategori`, `jenis`, `harga`, `ulasan`, `nm_foto`, `waktu`) VALUES
(12, 16, 'Nasi Goreng Ayam', 'Makanan', 'Pokok', 15000, 'Nasi goreng khas lombok dengan taburan ayam spesial', '14816375413756750.jpg', '2016-12-13 13:59:01'),
(13, 16, 'Es Teler ', 'Minuman', 'Minuman Dingin', 5000, 'Es teler dingin dengan buah - buahan', '1481637604es.jpg', '2016-12-13 14:00:04'),
(15, 18, 'Bakso Urat', 'Makanan', 'Cepat Saji', 17000, 'Bakso Urat Khas Malang dengan sensasi pedas.', '1481639438bakso3.jpg', '2016-12-13 14:30:38'),
(16, 19, 'Bakso Urat', 'Makanan', 'Cepat Saji', 17000, 'Bakso Urat Khas Malang dengan sensasi pedas.', '1481639483bakso3.jpg', '2016-12-13 14:31:23'),
(17, 20, 'Bakso Urat', 'Makanan', 'Cepat Saji', 17000, 'Bakso Urat Khas Malang dengan sensasi pedas.', '1481639528bakso3.jpg', '2016-12-13 14:32:08'),
(18, 18, 'Es Jeruk', 'Pilih Jenis Menu', 'Pilih Kategori Menu', 5000, 'Segarnya segelas jeruk asli dengan sensasi dingin.', '1481640034jeruk.JPG', '2016-12-13 14:36:47'),
(19, 19, 'Es Jeruk', 'Minuman', 'Minuman Dingin', 5000, 'Segarnya segelas jeruk asli dengan sensasi dingin.', '1481640232jeruk.JPG', '2016-12-13 14:43:52'),
(20, 16, 'Ayam Bakar Taliwang', 'Makanan', 'Lokal', 30000, 'Ayam bakar taliwang makanan khas Nusa Tenggara Barat', '1481646717ayam-taliwang.jpg', '2016-12-13 16:31:57'),
(21, 22, 'Sepat Mantap', 'Makanan', 'Pokok', 25000, 'Merupakan makanan khas dari sumbawa yang memiliki cita rasa yang beragam.', '1481676714sepat.jpeg', '2016-12-14 00:51:54'),
(22, 21, 'Es Krim Pot', 'Minuman', 'Minuman Dingin', 15000, 'Es krim buatan bu ragil murah ', '1481678284pot.jpg', '2016-12-14 01:17:27'),
(23, 22, 'Teh Tawar', 'Minuman', 'Minuman Hangat', 3000, 'Teh tawar biasa.', '1481678875teh tawar.jpg', '2016-12-14 01:24:39'),
(24, 23, 'Bolu Ketas', 'Makanan', 'Jajanan', 10000, 'Bolu hitam rasa coklat', '1481680960bolu.jpg', '2016-12-14 02:02:40');

-- --------------------------------------------------------

--
-- Table structure for table `suka`
--

CREATE TABLE `suka` (
  `id_suka` int(11) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `id_menu` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suka`
--

INSERT INTO `suka` (`id_suka`, `username`, `id_menu`) VALUES
(1, 'iqbaldp', 13),
(2, 'iqbaldp', 20),
(5, 'rigant', 22),
(6, 'nullpanthom', 16),
(7, 'iqbaldp', 24);

-- --------------------------------------------------------

--
-- Table structure for table `toko`
--

CREATE TABLE `toko` (
  `id_toko` int(11) NOT NULL,
  `id_user` varchar(30) NOT NULL,
  `nm_toko` varchar(40) DEFAULT NULL,
  `lokasi` varchar(20) DEFAULT NULL,
  `alamat` varchar(60) DEFAULT NULL,
  `jenis_usaha` varchar(20) DEFAULT NULL,
  `kontak` varchar(20) DEFAULT NULL,
  `stat_del` varchar(20) DEFAULT NULL,
  `jam_buka` varchar(25) DEFAULT NULL,
  `nm_foto` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `toko`
--

INSERT INTO `toko` (`id_toko`, `id_user`, `nm_toko`, `lokasi`, `alamat`, `jenis_usaha`, `kontak`, `stat_del`, `jam_buka`, `nm_foto`) VALUES
(16, 'iqbaldp', 'Rumah Makan Lombok', 'Mataram', 'Jln. Majapahit No. 62 Mataram', 'Rumah Makan', '087864576555', 'Ya', 'Pukul 07:00 - 20:00', '14816374731.jpg'),
(18, 'Iksanul15', 'Bakso Malang Soeretno Arjuno 1', 'Mataram', 'Jl. Pejanggik No.89A ', 'Rumah Makan', '0370628756', 'Tidak', '17.00-23.00', '1481638902bakso.jpg'),
(19, 'Iksanul15', 'Bakso Malang Soeretno Arjuno 2', 'Lombok Tengah', 'Jl. Soekarno No.42', 'Rumah Makan', '0370621736', 'Tidak', '17.00-23.00', '1481639049bakso1.jpg'),
(20, 'Iksanul15', 'Bakso Malang Soeretno Arjuno 3', 'Bima', 'Jl. Tolomundu No.12', 'Rumah Makan', '03706242112', 'Tidak', '17.00-23.00', '1481639167bakso2.jpg'),
(21, 'rigant', 'Es Krim Bu Ragil', 'Lombok Barat', 'Jl. Hasanudin No.22', 'Rumahan', '087865576123', 'Tidak', '10.00-22.00', '1481678336pott.jpg'),
(22, 'ghazgagah', 'Alas Daun', 'Sumbawa', 'Jl. Alas', 'Lesehan', '087864576555', 'Ya', 'Pukul 08:00 - 20:00', '1481676630rm.jpg'),
(23, 'iqbaldp', 'Cafe Kates', 'Dompu', 'Jln. Majapahit No. 62 Dompu', 'Cafe', '087864576555', 'Tidak', 'Pukul 08:00 - 20:00', '1481680891KatesCafe.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `nm_user` varchar(50) DEFAULT NULL,
  `username` varchar(30) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `tlp` varchar(12) DEFAULT NULL,
  `lokasi` varchar(30) DEFAULT NULL,
  `nm_foto` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`nm_user`, `username`, `email`, `password`, `tlp`, `lokasi`, `nm_foto`) VALUES
('Ghazwan Septrian Ahmad', 'ghazgagah', 'ghazwan@gmail.com', 'sega123', '087878676111', 'Sumbawa', '1481676511ghaz.jpg'),
('Muhammad Iksanul', 'Iksanul15', 'Iksanul15@gmail.com', 'namasaya', '085205852040', 'Mataram', '1481638669iksan.jpg'),
('ilhambintang', 'ilham', 'ilhambintang@gmail.com', 'bintang', '01021029', 'Mataram', '45074-O4G1GX.jpg'),
(' Muhammad Iqbal Dwi Putra        ', 'iqbaldp', 'iqbal.dp@yahoo.com', '123', ' 083129125  ', 'Lombok Barat', '8f8b380aac7658a3165cabe818afcc4c.jpg'),
('ilham bintang', 'nullpanthom', 'ilhambintang@gmail.com', 'bintang', NULL, NULL, NULL),
('Ragil Galuh', 'rigant', 'ragilgaluhp@gmail.com', 'ragil123', '', 'Pilih Lokasi Anda', '1481673619ragil.jpg'),
('Rozy', 'Rozi_1', 'Rozi@gmail.com', 'rozi', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id_menu`),
  ADD KEY `id_toko` (`id_toko`);

--
-- Indexes for table `suka`
--
ALTER TABLE `suka`
  ADD PRIMARY KEY (`id_suka`),
  ADD KEY `username` (`username`),
  ADD KEY `id_menu` (`id_menu`);

--
-- Indexes for table `toko`
--
ALTER TABLE `toko`
  ADD PRIMARY KEY (`id_toko`),
  ADD KEY `id_penjual` (`id_user`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`),
  ADD KEY `nm_user` (`nm_user`),
  ADD KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id_menu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `suka`
--
ALTER TABLE `suka`
  MODIFY `id_suka` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `toko`
--
ALTER TABLE `toko`
  MODIFY `id_toko` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `menu`
--
ALTER TABLE `menu`
  ADD CONSTRAINT `fk_menu` FOREIGN KEY (`id_toko`) REFERENCES `toko` (`id_toko`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `suka`
--
ALTER TABLE `suka`
  ADD CONSTRAINT `suka_ibfk_1` FOREIGN KEY (`username`) REFERENCES `user` (`username`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `suka_ibfk_2` FOREIGN KEY (`id_menu`) REFERENCES `menu` (`id_menu`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `toko`
--
ALTER TABLE `toko`
  ADD CONSTRAINT `fk_penjual` FOREIGN KEY (`id_user`) REFERENCES `user` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
